## AWS Microsoft Threat Modeling Tool Template
Microsoft Threat Modeling Tool Template containing AWS components and services

## How to use it?
1. Download and install [Microsoft Threat Modeling Tool](https://aka.ms/threatmodelingtool "Microsoft Threat Modeling Tool").
2. Open the tool and choose .tb7 file in "Template For new Models" field
3. Create A Model or open the example
4. Enjoy!

![AWS Threat Modeling Example](https://raw.githubusercontent.com/rusakovichma/aws-threat-modeling-tool-template/master/aws-threatmodeling-example.png)
